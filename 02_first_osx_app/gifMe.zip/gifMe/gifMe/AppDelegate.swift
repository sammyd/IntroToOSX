//
//  AppDelegate.swift
//  gifMe
//
//  Created by Sam Davies on 19/07/2015.
//  Copyright © 2015 RayWenderlich. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



  func applicationDidFinishLaunching(aNotification: NSNotification) {
    // Insert code here to initialize your application
  }

  func applicationWillTerminate(aNotification: NSNotification) {
    // Insert code here to tear down your application
  }


}

